#include "pch.h"
#include "Battle_Init.h"

void Battle_Init::Handle(CScene_Battle* _pScene)
{
}
