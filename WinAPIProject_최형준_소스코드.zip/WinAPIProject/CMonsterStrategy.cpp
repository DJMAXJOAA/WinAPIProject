#include "pch.h"
#include "CMonsterStrategy.h"
