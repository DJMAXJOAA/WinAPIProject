#include "pch.h"
#include "CRes.h"

CRes::CRes()
{
}

CRes::~CRes()
{
}