#include "pch.h"
#include "CUI.h"

#include "CKeyMgr.h"

#include "SelectGDI.h"

CUI::CUI(bool _bCamAff)
	: m_pParentUI(nullptr)
	, m_bCamAffected(_bCamAff)
	, m_bMouseOn(false)
	, m_bLbtnDown(false)
{
}

CUI::CUI(const CUI& _origin)
	: CObject(_origin)
	, m_pParentUI(nullptr)
	, m_bCamAffected(_origin.m_bCamAffected)
	, m_bMouseOn(false)
	, m_bLbtnDown(false)
{
	// �ڽ�UI�� ���� ����� �����Ѵ�
	for (size_t i = 0; i < _origin.m_vecChildUI.size(); i++)
	{
		AddChild(_origin.m_vecChildUI[i]->Clone());
	}
}

CUI::~CUI()
{
	SafeDeleteVec(m_vecChildUI);
}

void CUI::MouseOn()
{
}

void CUI::MouseLbtnDown()
{
}

void CUI::MouseLbtnUp()
{
}

void CUI::MouseLbtnClicked()
{
}

void CUI::MouseOnCheck()
{
	Vec2 vScale = GetScale();
	Vec2 vMousePos = MOUSE_POS;

	if (m_bCamAffected)
	{
		vMousePos = CCamera::GetInstance()->GetRealPos(vMousePos);
	}

	if (m_vFinalPos.x <= vMousePos.x && vMousePos.x <= m_vFinalPos.x + vScale.x
		&& m_vFinalPos.y <= vMousePos.y && vMousePos.y <= m_vFinalPos.y + vScale.y)
	{
		m_bMouseOn = true;
	}
	else
	{
		m_bMouseOn = false;
	}
}

void CUI::Update()
{
	Update_Child();
}

void CUI::FinalUpdate()
{
	CObject::FinalUpdate();

	m_vFinalPos = GetPos();

	if (GetParent()) // �θ� Ŭ������ ������, �θ� ��ġ��ŭ ������
	{
		Vec2 vParentPos = GetParent()->GetFinalPos();
		m_vFinalPos += vParentPos;
	}
	// UI ���콺 üũ
	MouseOnCheck();

	// �ڽ� Ŭ������ finalupdate�� �����ֱ�
	FinalUpdate_Child();
}

void CUI::Render(HDC hdc)
{
	Vec2 vPos = GetFinalPos();
	Vec2 vScale = GetScale();

	if (m_bCamAffected)
	{
		vPos = CCamera::GetInstance()->GetRenderPos(vPos);
	}

	if (m_bLbtnDown)
	{
		SelectGDI select(hdc, PEN_TYPE::GREEN);

		Rectangle(hdc
			, (int)(vPos.x - vScale.x / 2.f)
			, (int)(vPos.y - vScale.y / 2.f)
			, (int)(vPos.x + vScale.x / 2.f)
			, (int)(vPos.y + vScale.y / 2.f));
	}
	else
	{
		Rectangle(hdc
			, (int)(vPos.x - vScale.x / 2.f)
			, (int)(vPos.y - vScale.y / 2.f)
			, (int)(vPos.x + vScale.x / 2.f)
			, (int)(vPos.y + vScale.y / 2.f));
	}

	Render_Child(hdc);
}

void CUI::Update_Child()
{
	for (size_t i = 0; i < m_vecChildUI.size(); i++)
	{
		m_vecChildUI[i]->Update();
	}
}

void CUI::FinalUpdate_Child()
{
	for (size_t i = 0; i < m_vecChildUI.size(); i++)
	{
		m_vecChildUI[i]->FinalUpdate();
	}
}

void CUI::Render_Child(HDC hdc)
{
	for (size_t i = 0; i < m_vecChildUI.size(); i++)
	{
		m_vecChildUI[i]->Render(hdc);
	}
}
