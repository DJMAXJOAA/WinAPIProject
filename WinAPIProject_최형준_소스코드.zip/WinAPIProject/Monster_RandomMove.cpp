#include "pch.h"
#include "Monster_RandomMove.h"

void Monster_RandomMove::Handle(CScene_Battle* _pScen, CMonster* _pMone)
{

}
