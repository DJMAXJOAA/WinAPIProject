#include "pch.h"
#include "Monster_SelfHeal.h"

void Monster_SelfHeal::Handle(CScene_Battle* _pScene, CMonster* _pMon)
{
}
