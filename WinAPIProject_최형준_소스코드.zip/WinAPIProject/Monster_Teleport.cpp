#include "pch.h"
#include "Monster_Teleport.h"

void Monster_Teleport::Handle(CScene_Battle* _pScene, CMonster* _pMon)
{
}
