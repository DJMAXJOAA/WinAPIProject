#include "pch.h"
#include "PlayerTurn_TileSelect.h"

void PlayerTurn_TileSelect::Handle(CScene_Battle* _pScene)
{
}
