
#pragma once
// �̸� �����ϵ� ��� -> ��� cpp���Ͽ� �־�� ��

#include <Windows.h>
#include <stdio.h>

#include <iostream>
using std::cout;
using std::endl;
#include <vector>
using std::vector;
#include <string>
using std::string;
using std::to_string;
using std::wstring;
using std::to_wstring;
#include <map>
using std::map;
#include <unordered_map>
using std::unordered_map;
using std::pair;
using std::make_pair;
#include <set>
using std::set;
#include <list>
using std::list;
#include <random>
#include <functional>
using std::function;

#include <gdiplus.h>
using namespace Gdiplus;
#pragma comment(lib, "Gdiplus.lib")

#include <math.h>
#include <assert.h> // ���� ����
#pragma comment(lib, "Msimg32.lib") // TransparentBlt ���̺귯�� ����

#include "define.h"
#include "struct.h"
#include "func.h"